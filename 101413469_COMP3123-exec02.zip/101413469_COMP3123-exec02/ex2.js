const capitalize = (str) => {
    const [firstLetter, ...rest] = str;
    return `${firstLetter.toUpperCase()}${rest.join('')}`;
  };
  
  console.log(capitalize('fooBar'));
  console.log(capitalize('nodejs'));