const greeter = (myArray, counter) => {
    const greetText = 'Hello';
    for (const name of myArray) {
      console.log(`${greetText} ${name}`);
    }
  };
  
  greeter(["sahil", "bro", "canada"], 3);

  //https://github.com/sahils777/Comp3123-Labs