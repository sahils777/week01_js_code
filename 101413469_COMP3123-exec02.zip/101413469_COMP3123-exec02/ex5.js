var array = [1, 2, 3, 4];
var calculateSum = array.reduce(function(sum, num) {
    return sum + num;
}, 0);

var calculateProduct = array.reduce(function(product, num) {
    return product * num;
}, 1);

console.log(calculateSum);
console.log(calculateProduct);
