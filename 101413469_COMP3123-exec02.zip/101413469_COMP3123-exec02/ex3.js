const colors = ['red', 'green', 'blue'];

const capitalize = (str) => {
  const [firstLetter, ...rest] = str;
  return `${firstLetter.toUpperCase()}${rest.join('')}`;
};
const capitalizedColors = colors.map(color => capitalize(color));
console.log(capitalizedColors); 